from flask_app.config.mysqlconnection import connectToMySQL

class Dojo:
    db = "dojos_and_ninjas_db"
    def __init__(self,data):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM dojos;"
        results = connectToMySQL(cls.db).query_db(query)
        dojos = []
        for row in results:
            dojo = cls(row)
            dojos.append(dojo)
        return dojos

    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM dojos WHERE id=%(id)s"
        results = connectToMySQL(cls.db).query_db(query, data)
        if len(results) < 1:
            return False
        row = results[0]
        dojo = cls(row)
        return dojo

    @classmethod
    def get_one_with_name(cls, data):
        query = "SELECT * FROM dojos WHERE name=%(name)s"
        results = connectToMySQL(cls.db).query_db(query, data)
        if len(results) < 1:
            return False
        row = results[0]
        dojo = cls(row)
        return dojo

    @classmethod
    def save(cls, data):
        query = "INSERT INTO dojos(name) VALUES(%(name)s);"
        dojo_id = connectToMySQL(cls.db).query_db(query, data)
        return dojo_id

    @classmethod
    def update(cls, data):
        query = "UPDATE dojos SET name = %(name)s WHERE id = %(id)s;"
        dojo_id = connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def delete(cls, data):
        query = "DELETE FROM dojos WHERE id = %(id)s;"
        dojo_id = connectToMySQL(cls.db).query_db(query, data)
