from crypt import methods
from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.dojo import Dojo
from flask_app.models.ninja import Ninja

@app.route('/ninjas')
def ninjas_page():
    return render_template("ninjas.html", dojos=Dojo.get_all())

@app.route('/ninjas/create', methods=['POST'])
def create_ninja():
    Ninja.save(request.form)
    dojo_id = request.form['dojo_id']
    return redirect('/dojos/' + dojo_id)

@app.route('/reviews/<int:id>')
def show_review(id):
    user_data = {
        'id': session['id']
    }

    review_data = {
        "id": id
    }
    return render_template("show_review.html", review=Review.get_one(review_data), user=User.get_one(user_data))